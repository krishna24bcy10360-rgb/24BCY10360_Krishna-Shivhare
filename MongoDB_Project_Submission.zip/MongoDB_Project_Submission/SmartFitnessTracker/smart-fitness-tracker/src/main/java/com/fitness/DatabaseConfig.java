package com.fitness;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public class DatabaseConfig {
    private static final String CONNECTION_URI = "mongodb://127.0.0.1:27017";
    private static final String DATABASE_NAME = "FitnessTracker";
    private static MongoClient mongoClient = null;

    public static MongoDatabase getConnection() {
        if (mongoClient == null) {
            try {
                // Initialize Native MongoDB Driver Connection
                mongoClient = MongoClients.create(CONNECTION_URI);
                System.out.println("\n[SUCCESS] Connected successfully to MongoDB Local Engine at port 27017.");
            } catch (Exception e) {
                System.out.println("\n[ERROR] Database connection failed: " + e.getMessage());
            }
        }
        return mongoClient.getDatabase(DATABASE_NAME);
    }

    public static void closeConnection() {
        if (mongoClient != null) {
            mongoClient.close();
            System.out.println("[INFO] MongoDB Connection pooled shutdown complete.");
        }
    }
}