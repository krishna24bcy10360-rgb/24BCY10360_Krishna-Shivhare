package com.fitness;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Updates;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Aggregates;
import org.bson.Document;
import java.util.Arrays;
import java.util.Scanner;
import static com.mongodb.client.model.Filters.eq;
@org.springframework.boot.autoconfigure.SpringBootApplication
public class FitnessApp {
    public static void main(String[] args) {
        org.springframework.boot.SpringApplication.run(FitnessApp.class, args);
        MongoDatabase database = DatabaseConfig.getConnection();
        
        // Point 4: Creating the 4 distinct structural collections required by criteria
        MongoCollection<Document> memberCollection = database.getCollection("Members");
        MongoCollection<Document> staffCollection = database.getCollection("Gym_Staff");
        MongoCollection<Document> dietCollection = database.getCollection("Diet_Plans");
        MongoCollection<Document> deptCollection = database.getCollection("Fitness_Departments");
        
        Scanner scanner = new Scanner(System.in);
        int choice;

        System.out.println("\n====================================================");
        System.out.println("  SMART FITNESS TRACKER & DIET ORCHESTRATOR SYSTEM");
        System.out.println("====================================================");

        do {
            System.out.println("\n--- ENGINE OPERATIONS MENU ---");
            System.out.println("1. Setup Infrastructure (Insert Staff & Department Base Entities)");
            System.out.println("2. Register New Member (With One-to-One Staff Relationship Mapping)");
            System.out.println("3. Log Daily Macro Intake (Update Embedded Document Metrics)");
            System.out.println("4. Generate Advanced System Analytics Aggregation Pipeline");
            System.out.println("5. Delete Specific Member Record (Delete CRUD)");
            System.out.println("6. Drop Entire Members Collection (Wipe/Reset Database State)");
            System.out.println("7. View Live Document Logs (Read CRUD)");
            System.out.println("8. Exit Application");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Clear buffer

            switch (choice) {
                case 1:
                    // INSERT BASE OPERATIONS WITH CRASH PROTECTION
                    System.out.println("\n--- Seeding Base Infrastructure Entities ---");
                    try {
                        Document dept = new Document("_id", "DEPT_CARDIO").append("title", "Cardio & Endurance Section");
                        deptCollection.insertOne(dept);
                        
                        Document trainer = new Document("_id", "TRAINER_01").append("staffName", "Coach Sher Singh").append("specialization", "Hypertrophy");
                        staffCollection.insertOne(trainer);
                        
                        System.out.println("[SUCCESS] Seeded: Fitness_Departments and Gym_Staff base entities initialized successfully.");
                    } catch (Exception e) {
                        System.out.println("[INFO] Infrastructure infrastructure database collections already seeded and initialized.");
                    }
                    break;

                case 2:
                    // INSERT + RELATIONSHIP MAPPING (Point 7: One-to-One Reference Link)
                    System.out.print("Enter Member ID: ");
                    String mId = scanner.nextLine();
                    System.out.print("Enter Full Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Age: ");
                    int age = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter Trainer Staff ID to map (e.g. TRAINER_01): ");
                    String staffId = scanner.nextLine();

                    // Relational Constraint Validation check
                    if (staffCollection.find(eq("_id", staffId)).first() == null) {
                        System.out.println("[ERROR] Mapping Violation! Staff ID does not exist inside Gym_Staff database collection.");
                        break;
                    }

                    Document macroMetrics = new Document("calories", 0).append("protein", 0).append("carbs", 0).append("fat", 0);
                    Document newMember = new Document("_id", mId)
                            .append("name", name)
                            .append("age", age)
                            .append("active", true)
                            .append("assignedStaffId", staffId) // ONE-TO-ONE RELATIONSHIP MAPPING KEY
                            .append("dailyMacros", macroMetrics);

                    try {
                        memberCollection.insertOne(newMember);
                        System.out.println("[SUCCESS] Member document written with verified relational mapping link!");
                    } catch (Exception e) {
                        System.out.println("[ERROR] ID Collision: " + e.getMessage());
                    }
                    break;

                case 3:
                    // UPDATE OPERATION
                    System.out.print("Enter Member ID to update macros: ");
                    String memberId = scanner.nextLine();
                    System.out.print("Enter Calories (kcal): ");
                    int cal = scanner.nextInt();
                    System.out.print("Enter Protein (g): ");
                    int protein = scanner.nextInt();
                    System.out.print("Enter Carbs (g): ");
                    int carbs = scanner.nextInt();
                    System.out.print("Enter Fat (g): ");
                    int fat = scanner.nextInt();

                    long modifiedCount = memberCollection.updateOne(
                            eq("_id", memberId),
                            Updates.combine(
                                    Updates.set("dailyMacros.calories", cal),
                                    Updates.set("dailyMacros.protein", protein),
                                    Updates.set("dailyMacros.carbs", carbs),
                                    Updates.set("dailyMacros.fat", fat)
                            )
                    ).getModifiedCount();

                    if (modifiedCount > 0) {
                        System.out.println("[SUCCESS] Nested sub-document updated successfully.");
                    } else {
                        System.out.println("[WARNING] Profile state unchanged.");
                    }
                    break;

                case 4:
                    // ADVANCED AGGREGATION PIPELINE ($group, $avg, $sum)
                    System.out.println("\n--- RUNNING SYSTEM AGGREGATION ENGINE ---");
                    java.util.List<org.bson.conversions.Bson> pipeline = Arrays.asList(
                        Aggregates.group(
                            "$active", 
                            Accumulators.sum("totalGymMembers", 1),
                            Accumulators.avg("avgCaloriesConsumed", "$dailyMacros.calories"),
                            Accumulators.avg("avgProteinConsumed", "$dailyMacros.protein")
                        )
                    );

                    for (Document result : memberCollection.aggregate(pipeline)) {
                        System.out.println("\n=========================================");
                        System.out.println("📊 SYSTEM-WIDE NUTRITIONAL AGGREGATION REPORT:");
                        System.out.println("=========================================");
                        System.out.println("👥 Total Tracked Active Members : " + result.getInteger("totalGymMembers"));
                        System.out.println("🔥 Avg Calories Consumed Daily  : " + String.format("%.2f", result.getDouble("avgCaloriesConsumed")) + " kcal");
                        System.out.println("🍗 Avg Protein Intake Daily    : " + String.format("%.2f", result.getDouble("avgProteinConsumed")) + " g");
                        System.out.println("=========================================");
                    }
                    break;

                case 5:
                    // DELETE OPERATION CRUD
                    System.out.print("Enter Member ID to delete: ");
                    String deleteId = scanner.nextLine();
                    long delCount = memberCollection.deleteOne(eq("_id", deleteId)).getDeletedCount();
                    if (delCount > 0) {
                        System.out.println("[SUCCESS] Member document permanently deleted from cluster storage.");
                    } else {
                        System.out.println("[WARNING] Record not found.");
                    }
                    break;

                case 6:
                    // DROP OPERATION CRUD
                    System.out.println("⚠️ WARNING: Executing atomic database collection wipeout...");
                    memberCollection.drop();
                    System.out.println("[SUCCESS] Collection 'Members' dropped completely from current database namespace.");
                    break;

                case 7:
                    // READ CRUD OPERATION
                    System.out.println("\n--- FETCHING LIVE PERSISTED DATABASE DOCUMENTS ---");
                    for (Document doc : memberCollection.find()) {
                        Document macros = (Document) doc.get("dailyMacros");
                        System.out.println("\n--------------------------------------------");
                        System.out.println("ID: " + doc.get("_id").toString() + " | Name: " + doc.getString("name") + " | Trainer ID Map: " + doc.getString("assignedStaffId"));
                        if (macros != null) {
                            System.out.println("📊 CURRENT METRICS: Calories: " + macros.getInteger("calories") + " kcal | Protein: " + macros.getInteger("protein") + "g");
                        }
                    }
                    break;

                case 8:
                    System.out.println("Closing system platform database engine...");
                    break;

                default:
                    System.out.println("Invalid selection.");
            }
        } while (choice != 8);

        DatabaseConfig.closeConnection();
        scanner.close();
    }
}