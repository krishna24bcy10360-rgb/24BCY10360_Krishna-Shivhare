package com.fitness;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class FitnessController {

    // 1. MEMBERS DEPARTMENT ENDPOINT
    @GetMapping("/members")
    public List<Document> getMembers() {
        MongoDatabase database = DatabaseConfig.getConnection();
        MongoCollection<Document> collection = database.getCollection("Members");
        List<Document> list = new ArrayList<>();
        for (Document doc : collection.find()) {
            list.add(doc);
        }
        return list;
    }

    // 2. GYM STAFF DEPARTMENT ENDPOINT
    @GetMapping("/staff")
    public List<Document> getStaff() {
        MongoDatabase database = DatabaseConfig.getConnection();
        MongoCollection<Document> collection = database.getCollection("Gym_Staff");
        List<Document> list = new ArrayList<>();
        for (Document doc : collection.find()) {
            list.add(doc);
        }
        return list;
    }

    // 3. FITNESS INFRASTRUCTURE DEPARTMENTS ENDPOINT
    @GetMapping("/departments")
    public List<Document> getDepartments() {
        MongoDatabase database = DatabaseConfig.getConnection();
        MongoCollection<Document> collection = database.getCollection("Fitness_Departments");
        List<Document> list = new ArrayList<>();
        for (Document doc : collection.find()) {
            list.add(doc);
        }
        return list;
    }
}